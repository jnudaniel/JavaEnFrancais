/*
 * Fichier: ProjetFinal.java
 * ------------------------
 * Expliquez le sens de votre projet graphique ici.
 */
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.*;

import fr.*;

public class ProjetFinalGraphique extends FrGraphics {
	
	/**********************************************
	 *                 Constants                 *
	 **********************************************/

	/* Ne changez pas le nom de ces variables.
	 * Ils controllent la taille de la fenêtre.
	 */
	public static final int APPLICATION_WIDTH = 400;
	public static final int APPLICATION_HEIGHT = 500;

	/**********************************************
	 *                 Attributs                  *
	 **********************************************/
	// Vos attributs ici.

	public void run() {
		/* à vous d'être créatif/créative :) */
	}
}