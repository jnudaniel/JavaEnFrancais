/*
 * Fichier: NouvelleClasseConsole.java
 * -----------------------------------
 * Ce fichier contient une classe vide que vous pouvez changer selon
 * vos besoins. Rappellez-vous que si vous changez le nom de la classe
 * (nous vous conseillons de ne pas avoir plusieurs classes 
 * "NouvelleClasse"), il vous faudra ensuite changer le nom de ce
 * fichier d'une manière correspondante. (Dans Eclipse, cliquez avec
 * le bouton de droite sur le nom de ce fichier dans la liste à gauche,
 * puis sur 'Refactor' -> 'Rename', pour tout faire d'une seule étape.)
 * 
 * Supprimez ces détails et expliquez le sens de votre classe ici.
 */

import acm.program.*;
import java.util.*;
import fr.*;

public class NouvelleClasseConsole extends FrConsole {

	/**********************************************
	 *                 Attributs                  *
	 **********************************************/
	// Vos attributs ici.

	public void run() {
		/* à vous de créer ! */
	}
}

