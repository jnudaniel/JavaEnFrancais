/*
 * Fichier: NouveauKarel.java
 * --------------------------
 * Expliquez ici le sens de ce que Karel fait dans ce fichier.
 * 
 * Si vous changez le nom de la classe (nous vous conseillons de ne pas 
 * avoir plusieurs classes "NouveauKarel"), il vous faudra ensuite 
 * changer le nom de ce fichier d'une manière correspondante.
 * (Dans Eclipse, cliquez avec le bouton de droite sur le nom de ce 
 * fichier dans la liste à gauche, puis sur 'Refactor' -> 'Rename', 
 * pour tout faire d'une seule étape.)
 */

import frKarelPaquet.*;

public class NouveauKarel extends FrKarel {
	public void run() {
		/* Écrivez ici vos instructions et Karel les suivra */
	}
}
