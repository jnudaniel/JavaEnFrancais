/*
 * Fichier: ProjetFinalConsole.java
 * ------------------------
 * Expliquez le sens de votre projet console ici.
 */
import java.util.*;

import fr.*;

public class ProjetFinalConsole extends FrConsole {

	/**********************************************
	 *                 Attributs                  *
	 **********************************************/
	// Vos attributs ici.

	public void run() {
		/* à vous d'être créatif/créative :) */
	}
}