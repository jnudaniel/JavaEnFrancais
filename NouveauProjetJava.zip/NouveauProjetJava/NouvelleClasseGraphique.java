/*
 * Fichier: NouvelleClasseConsole.java
 * -----------------------------------
 * Ce fichier contient une classe vide que vous pouvez changer selon
 * vos besoins. Rappellez-vous que si vous changez le nom de la classe
 * (nous vous conseillons de ne pas avoir plusieurs classes 
 * "NouvelleClasse"), il vous faudra ensuite changer le nom de ce
 * fichier d'une manière correspondante. (Dans Eclipse, cliquez avec
 * le bouton de droite sur le nom de ce fichier dans la liste à gauche,
 * puis sur 'Refactor' -> 'Rename', pour tout faire d'une seule étape.)
 * 
 * Supprimez ces détails et expliquez le sens de votre classe ici.
 */

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.*;
import fr.*;

public class NouvelleClasseGraphique extends FrGraphics {
	
	/**********************************************
	 *                 Constants                 *
	 **********************************************/

	/* Ne changez pas le nom de ces variables.
	 * Ils controllent la taille de la fenêtre.
	 */
	public static final int APPLICATION_WIDTH = 400;
	public static final int APPLICATION_HEIGHT = 500;

	/**********************************************
	 *                 Attributs                  *
	 **********************************************/
	// Vos attributs ici.

	public void run() {
		/* à vous de créer ! */
	}
}